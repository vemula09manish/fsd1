CareCompass — Improved Frontend Demo

Run in VS Code:
1. Extract this ZIP and open the carecompass_improved folder.
2. Open index.html with the VS Code Live Server extension.

Files: index.html (structure), styles.css (responsive styling), app.js (data and interactions).

Features: hospital search; specialty, facility and bed filters; distance sorting after
location permission; Leaflet/OpenStreetMap map; call and directions links; demo bed editor;
local browser persistence; safer saved-data parsing; escaped dynamic text; responsive and
keyboard-focus styling; reduced-motion support.

Limitations: This is a frontend-only academic prototype. Hospital names, phone numbers,
coordinates and bed counts are sample data. The admin editor is not authenticated and
localStorage is not a secure database. A production version needs a Node.js/Express API,
SQLite or another database, server-side authentication and authorization, audit logging,
and automated tests. Do not use this demo for emergency dispatch or real care decisions.
In India, call 112 for emergencies. Map tiles require an internet connection.
